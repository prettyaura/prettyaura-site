# Prettyaura Hub ✨

This is the official link hub for **Prettyaura / Elite Aura**.

## Features
- Glassmorphism card with gold neon glow.
- Brand-colored square buttons (TikTok, YouTube, Store, Contact).
- WhatsApp full-width CTA.
- Responsive for mobile and desktop.
- Inline SVG icons for each platform.

## Deployment
Auto-deployed via [Vercel](https://vercel.com). Every commit to `main` redeploys the live site.

---
🌸 Prettyaura 🎀
